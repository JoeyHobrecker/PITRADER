"""Trading firm agent package."""
